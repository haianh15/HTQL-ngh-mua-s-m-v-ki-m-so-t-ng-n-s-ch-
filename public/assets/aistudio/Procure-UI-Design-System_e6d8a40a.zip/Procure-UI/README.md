# Procure UI — Design System v1.0

Design system đề xuất độc lập cho hệ thống quản lý đề nghị mua sắm và kiểm soát ngân sách nội bộ. Lấy cảm hứng từ mô hình nghiệp vụ Spendesk; không phải design system chính thức hoặc bản sao pixel-perfect.

## Tệp bàn giao
- design-system.html: tài liệu trực quan độc lập, mở bằng trình duyệt; có demo duyệt, modal từ chối và toast. Không yêu cầu internet.
- tokens.json: tokens màu, spacing, typography, layout, component và motion. Màu/spacing có cấu trúc $type/$value; các nhóm khác là cấu hình bổ sung, không cam kết import trực tiếp mọi công cụ tokens.
- procure-ui.css: CSS tham khảo được dùng trong HTML. HTML đã nhúng CSS nên không cần tải thêm.

## Nội dung
1. Nguyên tắc và phạm vi.
2. Semantic colors, typography, spacing, radius, responsive.
3. Buttons, form inputs, validation, badges, alerts và empty state.
4. Pattern chi tiết đề nghị với ngân sách và timeline phê duyệt.
5. Dashboard và bảng đề nghị mẫu.
6. Component contract, checklist accessibility và hướng dẫn handoff.

## Triển khai
Dùng CSS variables làm lớp semantic, không hardcode màu trong component sản phẩm. Có thể thay font mặc định bằng Inter bản self-host có hỗ trợ tiếng Việt. Không có file font được đính kèm.
Đề xuất tách component theo nhóm Button, Field, StatusBadge, Alert, BudgetCard, BudgetImpactPanel, ApprovalTimeline, DataTable, ConfirmDialog.
Tạo Figma pages: Cover, Foundations, Components, Patterns, Screens, Handoff; tokens phải được ánh xạ thủ công hoặc qua công cụ phù hợp. Bộ này không chứa file .fig.

## Business rules cần xác nhận
Công thức đề xuất: khả dụng = hạn mức + điều chỉnh ròng - thực chi - cam kết chưa thực chi - giữ chỗ chưa chuyển cam kết. Các nhóm phải không chồng lặp. Chính sách giữ chỗ tại thời điểm gửi/duyệt phải được BA và tài chính thống nhất trước lập trình.
Ngưỡng cảnh báo 80%, chặn/xin ngoại lệ tại 100% chỉ là đề xuất; quyết định chặn do server và policy thực tế.
Ví dụ: hạn mức 100 triệu; thực chi 40 triệu; cam kết 20 triệu; giữ chỗ 10 triệu; khả dụng 30 triệu. Đề nghị chờ 24 triệu chưa giữ chỗ; nếu duyệt/giữ chỗ sẽ còn 6 triệu. Nếu tiền đã giữ trước đó, không trừ lại.
PR chuyển PO phải chuyển nhóm số tiền; từ chối/hủy giải phóng khoản liên quan. Kiểm tra phiên bản và số dư lại ở server để tránh race condition.
Demo duyệt chỉ hoàn thành bước trưởng phòng, không hoàn thành toàn bộ workflow.

## Quality gates
Chưa audit WCAG đầy đủ hoặc test nhiều trình duyệt. Kiểm tra contrast, zoom 200%, screen reader, mobile 360px, focus restore và các tình huống số dài. Chế độ reduced-motion đã có CSS. Loading/error và responsive drawer được đặc tả nhưng chưa triển khai thành component runtime đầy đủ.
Không backend, không auth, không dữ liệu thật, không persist. Prototype không thay thế hệ thống production.

## Nguồn công khai — truy cập 28/10/2026
https://www.spendesk.com/product/budget/
https://www.spendesk.com/product/procurement/
Chỉ tham khảo guided intake, approval routing, budget visibility và committed spend. Mọi giá trị thị giác trong bộ này là đề xuất riêng, không được trích xuất từ Spendesk. Không dùng logo hoặc hình ảnh thương hiệu của họ.
